-- FIGYELEM: a script torli az autokolcsonzo_gyakorlat adatbazist, ha mar letezik!
DROP DATABASE IF EXISTS autokolcsonzo_gyakorlat;
CREATE DATABASE autokolcsonzo_gyakorlat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE autokolcsonzo_gyakorlat;

CREATE TABLE Gyartok (Id INT AUTO_INCREMENT PRIMARY KEY, Nev VARCHAR(100) NOT NULL);
CREATE TABLE Kategoriak (Id INT AUTO_INCREMENT PRIMARY KEY, Nev VARCHAR(100) NOT NULL UNIQUE);
CREATE TABLE Autok (
 Id INT AUTO_INCREMENT PRIMARY KEY, Rendszam VARCHAR(10) NOT NULL UNIQUE, Modell VARCHAR(100) NOT NULL,
 GyartoId INT NOT NULL, KategoriaId INT NOT NULL, Evjarat INT NOT NULL, NapiDij INT NOT NULL,
 FOREIGN KEY (GyartoId) REFERENCES Gyartok(Id),
 FOREIGN KEY (KategoriaId) REFERENCES Kategoriak(Id)
);
CREATE TABLE Ugyfelek (
 Id INT AUTO_INCREMENT PRIMARY KEY, Nev VARCHAR(100) NOT NULL,
 Email VARCHAR(150) NOT NULL UNIQUE, Aktiv BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE Berlesek (
 Id INT AUTO_INCREMENT PRIMARY KEY, AutoId INT NOT NULL, UgyfelId INT NOT NULL,
 Kezdete DATE NOT NULL, Hatarido DATE NOT NULL, Visszahozva DATE NULL,
 FOREIGN KEY (AutoId) REFERENCES Autok(Id),
 FOREIGN KEY (UgyfelId) REFERENCES Ugyfelek(Id)
);
INSERT INTO Gyartok VALUES
(1,'Suzuki'),(2,'Toyota'),(3,'Skoda'),(4,'Volkswagen'),
(5,'Ford'),(6,'Opel'),(7,'Renault');
INSERT INTO Kategoriak VALUES
(1,'Kisautó'),(2,'Kompakt'),(3,'Családi'),(4,'Kisbusz'),(5,'Elektromos');
INSERT INTO Autok VALUES
(1,'AAB-123','Swift',1,1,2019,9000),
(2,'AAC-456','Corolla',2,2,2021,14000),
(3,'AAD-789','Octavia Combi',3,3,2020,16000),
(4,'AAE-321','Transporter',4,4,2018,24000),
(5,'AEF-654','Focus',5,2,2017,12000),
(6,'AFG-987','Zafira',6,3,2016,13000),
(7,'AIH-111','Zoe',7,5,2022,15000),
(8,'AJK-222','Yaris',2,1,2023,10000),
(9,'AKL-333','ID.3',4,5,2023,18000);
INSERT INTO Ugyfelek VALUES
(1,'Horváth Máté','horvath.mate@example.com',TRUE),
(2,'Molnár Eszter','molnar.eszter@example.com',TRUE),
(3,'Balogh Ádám','balogh.adam@example.com',TRUE),
(4,'Farkas Lilla','farkas.lilla@example.com',TRUE),
(5,'Takács Gergő','takacs.gergo@example.com',FALSE),
(6,'Papp Zsófia','papp.zsofia@example.com',TRUE),
(7,'Németh Bálint','nemeth.balint@example.com',TRUE);
-- Egy autohoz legfeljebb egy aktiv berles tartozik.
INSERT INTO Berlesek VALUES
(1,1,1,'2026-10-20','2026-10-27',NULL),
(2,2,2,'2026-11-01','2026-11-15',NULL),
(3,3,3,'2026-10-25','2026-11-04',NULL),
(4,5,4,'2026-11-03','2026-11-08',NULL),
(5,6,6,'2026-11-05','2026-11-12',NULL),
(6,7,1,'2026-10-28','2026-11-07',NULL),
(7,8,2,'2026-11-08','2026-11-10',NULL),
(8,9,3,'2026-09-05','2026-09-12','2026-09-12'),
(9,1,4,'2026-09-10','2026-09-17','2026-09-19'),
(10,2,6,'2026-09-14','2026-09-21','2026-09-21'),
(11,9,7,'2026-09-20','2026-10-04','2026-10-03'),
(12,3,1,'2026-09-25','2026-10-02','2026-10-02'),
(13,7,2,'2026-10-01','2026-10-08','2026-10-10'),
(14,5,3,'2026-10-05','2026-10-12','2026-10-12'),
(15,9,4,'2026-10-10','2026-10-17','2026-10-16'),
(16,6,7,'2026-10-12','2026-10-19','2026-10-19'),
(17,8,6,'2026-10-15','2026-10-22','2026-10-24'),
(18,1,2,'2026-10-01','2026-10-08','2026-10-07');
-- Ellenorzes
SELECT COUNT(*) AS Autok FROM Autok;
SELECT COUNT(*) AS AktivBerlesek FROM Berlesek WHERE Visszahozva IS NULL;
