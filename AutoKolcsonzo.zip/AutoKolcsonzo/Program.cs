using AutokolcsonzoConsole;
using AutokolcsonzoLibrary.Services;


using var db = new AutokolcsonzoDbContext();
IAutokolcsonzoService service = new AutokolcsonzoService(db);
new Menu(service).Futtatas();
